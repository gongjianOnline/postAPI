const router = require('koa-router')()
const axios = require('axios');

router.get('/get', async (ctx, next) => {
  console.log(ctx.header.realurl);
  var response = await axios.get(ctx.header.realurl);
  ctx.body = JSON.stringify(response.data)
})

router.post('/post', async (ctx, next) => {
  console.log(ctx.request.body);
  var response = await axios({
    methods:'post',
    headers:{},
    data:ctx.request.body,
    url:ctx.header.realurl
  });
  ctx.body = JSON.stringify(response.data)
})




module.exports = router
